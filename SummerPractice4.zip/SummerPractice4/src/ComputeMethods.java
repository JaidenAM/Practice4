import java.util.Random;


public class ComputeMethods {
    
    
}

